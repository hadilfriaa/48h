document.getElementById("resultname").innerHTML=localStorage.getItem("nameid");
document.getElementById("resultprenom").innerHTML=localStorage.getItem("prenomid");
document.getElementById("resultnumero").innerHTML=localStorage.getItem("numeroid");
document.getElementById("resultmedicament").innerHTML=localStorage.getItem("medicamentid");
document.getElementById("resultposologie").innerHTML=localStorage.getItem("posologieid");